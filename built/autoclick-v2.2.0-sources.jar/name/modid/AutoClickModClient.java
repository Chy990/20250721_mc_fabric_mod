package name.modid;
import org.json.JSONObject;
import org.json.JSONArray;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1268;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;

public class AutoClickModClient implements ClientModInitializer {
    private static boolean autoClickEnabled = false;
    private static long lastClickTime = 0;
    private static double clickInterval = 0.6;
    private static boolean deepSeekChatMode = false;
    private static final HttpClient httpClient = HttpClient.newHttpClient();
    private static final String DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"; // 替换为你的API地址
    private static final String API_KEY = "sk-c00f9091f0e94270ad833085d71dc4ce"; // 替换为你的API密钥

    @Override
    public void onInitializeClient() {
        // 注册自动点击命令
        registerAutoClickCommand();
        
        // 注册DeepSeek聊天命令
        registerSayCommand();
        registerDeepSeekCommand();
        
        // 自动点击逻辑
        registerAutoClickLogic();
        
        // DeepSeek聊天消息处理
        registerMessageHandler();

        registerHelpCommand();

    }

    private void registerHelpCommand() {
    ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
        dispatcher.register(
            ClientCommandManager.literal("chy_help")
                .executes(context -> {
                    context.getSource().sendFeedback(class_2561.method_30163("§6=== chy帮助菜单 ==="));
                    context.getSource().sendFeedback(class_2561.method_30163("§e/chy_autoattack [间隔秒] §7- 开启/关闭自动攻击，支持可选参数设置攻击间隔（单位：秒）。默认频率0.6秒。"));
                    context.getSource().sendFeedback(class_2561.method_30163("§e/chy_deepseek §7- 开启或关闭 DeepSeek 聊天模式，在聊天中直接对话"));
                    context.getSource().sendFeedback(class_2561.method_30163("§e/chy_help §7- 查看此帮助菜单"));
                    context.getSource().sendFeedback(class_2561.method_30163("§6使用说明："));
                    context.getSource().sendFeedback(class_2561.method_30163("§7- 开启 DeepSeek 后，在聊天中输入内容会自动请求 AI 回复"));
                    context.getSource().sendFeedback(class_2561.method_30163("§7- 自动攻击适合挂机或练手用，建议注意使用场景"));
                    return 1;
                })
        );
    });
}


    private void registerAutoClickCommand() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                ClientCommandManager.literal("chy_autoattack")
                    .executes(context -> {
                        autoClickEnabled = !autoClickEnabled;
                        context.getSource().sendFeedback(class_2561.method_30163("自动点击已 " + (autoClickEnabled ? "开启" : "关闭") + " (间隔: " + clickInterval + "秒)"));
                        return 1;
                    })
                    .then(ClientCommandManager.argument("interval", FloatArgumentType.floatArg(0.01f, 10.0f))
                    .executes(context -> {
                        float newInterval = FloatArgumentType.getFloat(context, "interval");
                        clickInterval = newInterval;
                        autoClickEnabled = true;
                        context.getSource().sendFeedback(class_2561.method_30163("自动点击已开启 (间隔: " + clickInterval + "秒)"));
                        return 1;
                    }))
            );
        });
    }

    private void registerSayCommand() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                ClientCommandManager.literal("chy_say")
                    .then(ClientCommandManager.argument("message", StringArgumentType.greedyString())
                        .executes(context -> {
                            String msg = StringArgumentType.getString(context, "message");

                            // 1. 发送到聊天
                            class_310.method_1551().field_1724.field_3944.method_45729(msg);

                            // 2. DeepSeek 回复
                            if (deepSeekChatMode) {
                                CompletableFuture.runAsync(() -> {
                                    try {
                                        String response = callDeepSeekAPI(msg);
                                        class_310.method_1551().execute(() -> {
                                            class_310.method_1551().field_1724.method_7353(class_2561.method_30163("DeepSeek: " + response), false);
                                        });
                                    } catch (Exception e) {
                                        class_310.method_1551().execute(() -> {
                                            class_310.method_1551().field_1724.method_7353(class_2561.method_30163("调用DeepSeek出错: " + e.getMessage()), false);
                                        });
                                    }
                                });
                            }
                            return 1;
                        })
                    )
            );
        });
    }

    private void registerDeepSeekCommand() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                ClientCommandManager.literal("chy_deepseek")
                    .executes(context -> {
                        deepSeekChatMode = !deepSeekChatMode;
                        if (deepSeekChatMode) {
                            context.getSource().sendFeedback(class_2561.method_30163("DeepSeek聊天模式已开启，请输入你的问题"));
                        } else {
                            context.getSource().sendFeedback(class_2561.method_30163("DeepSeek聊天模式已关闭"));
                        }
                        return 1;
                    })
            );
        });
    }

    private void registerAutoClickLogic() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (autoClickEnabled && client.field_1724 != null && client.field_1761 != null) {
                long currentTime = System.currentTimeMillis();
                long intervalMillis = (long)(clickInterval * 1000);
                
                if (currentTime - lastClickTime >= intervalMillis) {
                    class_304 attackKey = client.field_1690.field_1886;
                    boolean originalState = attackKey.method_1434();
                    attackKey.method_23481(true);
                    
                    if (client.field_1692 != null) {
                        client.field_1761.method_2918(client.field_1724, client.field_1692);
                    }
                    
                    client.field_1724.method_6104(class_1268.field_5808);
                    attackKey.method_23481(originalState);
                    lastClickTime = currentTime;
                }
            }
        });
    }

    private void registerMessageHandler() {
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            if (deepSeekChatMode && class_310.method_1551().field_1724 != null) {
                String userMessage = message.getString();
                
                // 忽略命令消息
                if (userMessage.startsWith("/")) {
                    return;
                }
                
                // 异步发送API请求
                CompletableFuture.runAsync(() -> {
                    try {
                        String response = callDeepSeekAPI(userMessage);
                        class_310.method_1551().execute(() -> {
                            class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_30163("§bDeepSeek§f: " + response));
                        });
                    } catch (Exception e) {
                        class_310.method_1551().execute(() -> {
                            class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_30163("§c调用 DeepSeek 出错: " + e.getMessage()));

                        });
                    }
                });
            }
        });
    }



    private String callDeepSeekAPI(String message) throws IOException, InterruptedException {
        String requestBody = String.format("""
        {
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": "%s"}],
            "temperature": 0.7,
            "stream": false
        }
        """, message);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(DEEPSEEK_API_URL))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + API_KEY)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        // 解析 JSON
        JSONObject json = new JSONObject(response.body());
        JSONArray choices = json.getJSONArray("choices");
        if (choices.length() > 0) {
            JSONObject messageObj = choices.getJSONObject(0).getJSONObject("message");
            return messageObj.getString("content");
        } else {
            return "未收到有效的回答";
        }
    }

}